package com.mobiles.dao;

import java.util.List;

import org.springframework.stereotype.Service;

import com.mobiles.entity.Cart;


@Service
public interface CartDao {

	public void addCart(Cart c);

	public List<Cart> getAllCart();
	
	public void deleteCart(int id);
	
	public void updateCart(Cart c);
	
	public Cart getCartMobileById(int mobileId);
}

