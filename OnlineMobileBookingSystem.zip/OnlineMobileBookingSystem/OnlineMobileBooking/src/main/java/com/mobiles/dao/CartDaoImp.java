package com.mobiles.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

import com.mobiles.entity.Cart;
import com.mobiles.repo.CartRepository;

@Service
public class CartDaoImp implements CartDao{
	
	@Autowired
	CartRepository cartRepo;

	@Override
	public void addCart(Cart c) {
		// TODO Auto-generated method stub
		cartRepo.save(c);
	}

	@Override
	public List<Cart> getAllCart() {
		// TODO Auto-generated method stub
		List<Cart> list = cartRepo.findAll();
		return list;
	}

	@Override
	public void deleteCart(int id) {
		// TODO Auto-generated method stub
		cartRepo.deleteById(id);
	}

	@Override
	public void updateCart(Cart c) {
		// TODO Auto-generated method stub
		cartRepo.save(c);
	}

	
	@Override
	public Cart getCartMobileById(int mobileId) {
		// TODO Auto-generated method stub
		Cart cart = cartRepo.getById(mobileId);
		return cart;	}

}
