package com.mobiles.entity;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

import org.apache.tomcat.util.codec.binary.Base64;

import org.springframework.stereotype.Component;
@Entity
@Table(name="mobiles")
@Component
public class Mobiles {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int mobileId;
	private String mobileName;
	private String category;
	private boolean availability;
	private double mobilePrice;
	private int quantity;
	@Lob
	private byte[] pic;
	
	
	public Mobiles() {
		super();
		// TODO Auto-generated constructor stub
	}


	public Mobiles(int mobileId, String mobileName, String category, boolean availability, double mobilePrice,
			int quantity, byte[] pic) {
		super();
		this.mobileId = mobileId;
		this.mobileName = mobileName;
		this.category = category;
		this.availability = availability;
		this.mobilePrice = mobilePrice;
		this.quantity = quantity;
		this.pic = pic;
	}


	public int getMobileId() {
		return mobileId;
	}
	public void setMobileId(int mobileId) {
		this.mobileId = mobileId;
	}
	public String getMobileName() {
		return mobileName;
	}
	public void setMobileName(String mobileName) {
		this.mobileName = mobileName;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public boolean isAvailability() {
		return availability;
	}
	public void setAvailability(boolean availability) {
		this.availability = availability;
	}
	public double getMobilePrice() {
		return mobilePrice;
	}
	public void setMobilePrice(double mobilePrice) {
		this.mobilePrice = mobilePrice;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public byte[] getPic() {
		return pic;
	}
	public void setPic(byte[] pic) {
		this.pic = pic;
	}

	@Override
	public String toString() {
		return "Mobiles [mobileId=" + mobileId + ", mobileName=" + mobileName + ", category=" + category
				+ ", availability=" + availability + ", mobilePrice=" + mobilePrice + ", quantity=" + quantity
				 + "]";
	}
	public String getItemPic() {
		return Base64.encodeBase64String(pic);
	}

	

}
