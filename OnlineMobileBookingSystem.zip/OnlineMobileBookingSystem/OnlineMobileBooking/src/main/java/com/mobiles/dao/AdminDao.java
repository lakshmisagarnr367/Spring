package com.mobiles.dao;

import com.mobiles.entity.Admin;
import org.springframework.stereotype.Service;


@Service
public interface AdminDao {
	public void addAdmin(Admin admin);
	
	
	public Admin validateAdmin(Admin admin);

}
