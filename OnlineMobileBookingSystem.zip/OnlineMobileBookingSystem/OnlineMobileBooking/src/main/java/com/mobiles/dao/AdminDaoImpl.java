package com.mobiles.dao;

import com.mobiles.entity.Admin;
import com.mobiles.repo.adminRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AdminDaoImpl implements AdminDao {
	@Autowired
	adminRepo repo;

	@Override
	public void addAdmin(Admin admin) {
		// TODO Auto-generated method stub
		repo.save(admin);
	}

	@Override
	public Admin validateAdmin(Admin admin) {
		// TODO Auto-generated method stub
		Admin ad = repo.findByLoginData(admin.getEmailId(), admin.getPassword());
		return ad;
	}

	
	

}
