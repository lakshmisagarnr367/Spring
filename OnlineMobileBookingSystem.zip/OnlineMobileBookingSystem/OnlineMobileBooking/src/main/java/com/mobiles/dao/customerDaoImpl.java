package com.mobiles.dao;

import java.util.List;

import com.mobiles.entity.Mobiles;
import com.mobiles.entity.Customer;
import com.mobiles.repo.mobilesRepo;
import com.mobiles.repo.customerRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class customerDaoImpl implements customerDao {
	
	@Autowired 
	customerRepo repo;
	
	@Autowired 
	mobilesRepo brepo;

	@Override
	public void addCustomer(Customer customer) {
		// TODO Auto-generated method stub
		repo.save(customer);
		}

	@Override
	public List<Customer> getAllCustomers() {
		// TODO Auto-generated method stub
		List<Customer> customerList=repo.findAll();
		return customerList;
	}

	@Override
	public Customer getCustomerById(int customerId) {
		// TODO Auto-generated method stub
		Customer customer=repo.getById(customerId);
		return customer;
	}

	
	@Override
	public Customer validateCustomer(Customer customer) {
		// TODO Auto-generated method stub
		Customer customer1=repo.findbyCustomerLoginData(customer.getEmailId(), customer.getPassword());
		return customer1;
	}

}
