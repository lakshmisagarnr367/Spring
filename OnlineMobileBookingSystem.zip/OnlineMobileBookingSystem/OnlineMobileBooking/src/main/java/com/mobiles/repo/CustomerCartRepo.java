package com.mobiles.repo;

import com.mobiles.entity.CustomerCart;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CustomerCartRepo extends JpaRepository<CustomerCart, Integer>{

}
