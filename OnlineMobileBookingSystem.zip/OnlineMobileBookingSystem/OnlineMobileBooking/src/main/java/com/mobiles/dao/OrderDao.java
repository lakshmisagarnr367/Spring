package com.mobiles.dao;

import java.util.List;

import com.mobiles.entity.OrderDetail;
import org.springframework.stereotype.Service;

@Service
public interface OrderDao {
	
	public void addOrder(OrderDetail order);

	public List<OrderDetail> getAllOrder();
	
	public void deleteOrder(int orderId);
	
	public void updateOder(OrderDetail order);
	

}
