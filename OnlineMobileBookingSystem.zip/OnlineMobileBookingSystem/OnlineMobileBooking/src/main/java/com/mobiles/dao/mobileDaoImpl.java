package com.mobiles.dao;

import java.util.List;

import com.mobiles.entity.Mobiles;
import com.mobiles.repo.mobilesRepo;

import com.mobiles.entity.Mobiles;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class mobileDaoImpl implements mobilesDao {
	@Autowired
	mobilesRepo repomobile;
	
	
	@Override
	public void addMobiles(Mobiles mobile) {
		// TODO Auto-generated method stub
		repomobile.save(mobile);
	}

	@Override
	public List<Mobiles> getallMobiles() {
		// TODO Auto-generated method stub
		List<Mobiles> mobilelist=repomobile.findAll();
		return mobilelist;
	}

	@Override
	public Mobiles getmobileById(int mobileId) {
		// TODO Auto-generated method stub
		Mobiles mobile=repomobile.getById(mobileId);
		return mobile;
	}

	@Override
	public void updateMobile(Mobiles mobile) {
		// TODO Auto-generated method stub
		repomobile.save(mobile);
	}

	@Override
	public void deleteMobile(int mobileId) {
		// TODO Auto-generated method stub
		repomobile.deleteById(mobileId);
	}

}
