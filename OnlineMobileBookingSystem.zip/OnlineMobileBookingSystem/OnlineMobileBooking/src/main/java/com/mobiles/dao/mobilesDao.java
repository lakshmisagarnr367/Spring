package com.mobiles.dao;

import java.util.List;

import com.mobiles.entity.Mobiles;
import org.springframework.stereotype.Service;



@Service
public interface mobilesDao {
	
	public void addMobiles(Mobiles mobile);
	public List<Mobiles> getallMobiles();
	public Mobiles getmobileById(int mobileId);
	public void updateMobile(Mobiles mobile);
	public void deleteMobile(int mobileId);
}
