package com.mobiles.dao;

import com.mobiles.entity.CustomerCart;
import org.springframework.stereotype.Service;

@Service
public interface CustomerCartDao {
	
	public void addCustomerCart(CustomerCart customercart);

}
